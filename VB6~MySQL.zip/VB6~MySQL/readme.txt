# VB6-MySQL


VB6/MySQL

A VB6 Front-end to a MySQL database. 

Used for writing quickly to the server database for the freewalks project (the PHP/MySQL example in this github account).



An example of strong VB6/ADO coding with embedded SQL and error trapping and logging.

need:

mysql-connector-odbc-5.1.6-winx64.msi